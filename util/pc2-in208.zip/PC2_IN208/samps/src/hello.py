#
# File:    hello.py
# Purpose: to print hello world in Python
# Author:  pc2@ecs.csus.edu or http://www.ecs.csus.edu/pc2
#

import sys
sys.stdout.softspace=0
# softspace required to avoid extra space after print 

print("Hello World.")

# eof $Id$
